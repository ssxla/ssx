with open(r'F:\\ok.txt') as f1:
	with open(r'F:\\url.txt','w') as f2:
		cNames=	f1.read().splitlines()
		for i in range(0,len(cNames)):
			if 'php?' in cNames[i]:
				f2.write(cNames[i]+'\n')